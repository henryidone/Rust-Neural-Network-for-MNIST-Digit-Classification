use serde::de::{self, Deserialize, Deserializer, SeqAccess, Visitor};
use ndarray::{Array2, Array, Axis};
use ndarray_rand::RandomExt;
use ndarray_rand::rand_distr::Normal;
use csv::ReaderBuilder;
use std::error::Error;
use rand::seq::SliceRandom;

struct Mnistdatarow {
    name: u8,
    grayvals: [u8; 784],
}
impl<'de> Deserialize<'de> for Mnistdatarow {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        struct Mnistdatarowvisit;
        impl<'de> Visitor<'de> for Mnistdatarowvisit {
            type Value = Mnistdatarow;
            fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
                formatter.write_str("a label and 784 pixel values")
            }
            fn visit_seq<V>(self, mut seq: V) -> Result<Mnistdatarow, V::Error>
            where
                V: SeqAccess<'de>,
            {
                let name = match seq.next_element()? {
                    Some(val) => val,
                    None => return Err(de::Error::invalid_length(0, &self)),
                };
                let mut grayvals = [0u8; 784];
                for (i, pixel) in grayvals.iter_mut().enumerate() {
                    *pixel = match seq.next_element()? {
                        Some(val) => val,
                        None => return Err(de::Error::invalid_length(i + 1, &self)),
                    };
                }
                Ok(Mnistdatarow { name, grayvals })
            }
        }
        deserializer.deserialize_seq(Mnistdatarowvisit)
    }
}
struct NeuralNetwork {
    weightsinputhidden: Array2<f32>,
    weightshiddenoutput: Array2<f32>,
}
impl NeuralNetwork {
    fn new(nodes: usize, hidden: usize, out: usize) -> Self {
        let weightsinputhidden = Self::initializeweights(nodes, hidden);
        let weightshiddenoutput = Self::initializeweights(hidden, out);
        Self {
            weightsinputhidden,
            weightshiddenoutput,
        }
    }
    fn initializeweights(rows: usize, cols: usize) -> Array2<f32> {
        let stddev = (2.0 / (rows + cols) as f32).sqrt();
        Array::random((rows, cols), Normal::new(0.0, stddev).unwrap())
    }
    fn sigmoid(x: &Array2<f32>) -> Array2<f32> {
        x.mapv(|v| 1.0 / (1.0 + (-v).exp()))
    }
    fn softmax(x: &Array2<f32>) -> Array2<f32> {
        let maxvals = x.map_axis(Axis(1), |row| *row.iter().max_by(|a, b| a.partial_cmp(b).unwrap()).unwrap());
        let stabilized = x - &maxvals.insert_axis(Axis(1));
        let expvals = stabilized.mapv(|v| v.exp());
        let sums = expvals.sum_axis(Axis(1)).insert_axis(Axis(1));
        expvals/sums
    }
    fn forward(&self, input: &Array2<f32>) -> (Array2<f32>, Array2<f32>) {
        let hiddeninput = input.dot(&self.weightsinputhidden);
        let hiddenoutput = Self::sigmoid(&hiddeninput);
        let finalinput = hiddenoutput.dot(&self.weightshiddenoutput);
        let finaloutput = Self::softmax(&finalinput);
        (hiddenoutput, finaloutput)
    }
    fn backward(
        &mut self,
        input: &Array2<f32>,
        hidden: &Array2<f32>,
        output: &Array2<f32>,
        labels: &Array2<f32>,
        learnrate: f32,
    ) {
        let outputerror = output - labels;
        let hiddenerror = outputerror.dot(&self.weightshiddenoutput.t()) * hidden * (1.0 - hidden);
        let gradoutput = hidden.t().dot(&outputerror) * learnrate;
        let gradhidden = input.t().dot(&hiddenerror) * learnrate;
        self.weightshiddenoutput -= &gradoutput;
        self.weightsinputhidden -= &gradhidden;
    }
}
fn onehot(names: &Array2<f32>, totclasses: usize) -> Array2<f32> {
    let mut oh = Array2::zeros((names.shape()[0], totclasses));
    for (i, &name) in names.iter().enumerate() {
        oh[[i, name as usize]] = 1.0;
    }
    oh
}
fn diffcalc(output: &Array2<f32>, target: &Array2<f32>) -> f32 {
    let epsilon = 1e-12;
    let clipped = output.mapv(|v| v.clamp(epsilon, 1.0 - epsilon));
    let mut cumloss = 0.0;
    for (clip, row_target) in clipped.outer_iter().zip(target.outer_iter()) {
        let mut rowminus = 0.0;
        for (o, t) in clip.iter().zip(row_target.iter()) {
            rowminus += t * o.ln();
        }
        cumloss -= rowminus;
    }
    cumloss / output.nrows() as f32
}
fn load_mnist_data(file_path: &str) -> Result<(Array2<f32>, Array2<f32>), Box<dyn Error>> {
    let mut reader = ReaderBuilder::new().has_headers(false).from_path(file_path)?;
    let mut names = Vec::new();
    let mut grayvals = Vec::new();
    for result in reader.deserialize::<Mnistdatarow>() {
        let row: Mnistdatarow = result?;
        names.push(row.name as f32);
        grayvals.extend(row.grayvals.iter().map(|&p| p as f32 / 255.0));
    }
    let arrnames = Array2::from_shape_vec((names.len(), 1), names.clone())?;
    let arrgray = Array2::from_shape_vec((names.len(), 784), grayvals)?;
    Ok((arrnames, arrgray))
}
fn train(
    nn: &mut NeuralNetwork,
    traingrayvals: &Array2<f32>,
    trainnames: &Array2<f32>,
    epochs: usize,
    mut learnspeed: f32,
    size: usize,
) {
    let samples = traingrayvals.nrows();
    let indices: Vec<usize> = (0..samples).collect();
    for epoch in 1..=epochs {
        let mut shuffled = indices.clone();
        shuffled.shuffle(&mut rand::thread_rng());
        for batchbegin in (0..samples).step_by(size) {
            let batchend = (batchbegin + size).min(samples);
            let batchindex = &shuffled[batchbegin..batchend];
            let batchpix = traingrayvals.select(Axis(0), batchindex);
            let batchname = trainnames.select(Axis(0), batchindex);
            let (hidout, finalout) = nn.forward(&batchpix);
            nn.backward(&batchpix, &hidout, &finalout, &batchname, learnspeed);
        }
        let (_, finalout) = nn.forward(traingrayvals);
        let loss = diffcalc(&finalout, trainnames);
        println!("Epoch {}: Loss ({:.4}), Learning Rate  ({:.4})", epoch, loss, learnspeed);
        learnspeed *= 0.995;
    }
}
fn evaluate(nn: &NeuralNetwork, testgrayvals: &Array2<f32>, testname: &Array2<f32>) {
    let (_, predictions) = nn.forward(testgrayvals);
    let mut correct = 0;
    for (prediction, name) in predictions.outer_iter().zip(testname.iter()) {
        let mut max = -f32::INFINITY;
        let mut predlabel: usize = 0;
        for (i, &value) in prediction.iter().enumerate() {
            if value > max {
                max = value;
                predlabel = i;
            }
        }
        if predlabel == *name as usize {
            correct += 1;
        }
    }
    let accuracy = correct as f32 / testname.len() as f32;
    println!("{}/{} are correct", correct, testname.len());
    println!("It is {:.2}% accurate", accuracy * 100.0);
}
fn main() -> Result<(), Box<dyn Error>> {
    let trainpath = "mnist_train.csv";
    let testpath = "mnist_test.csv";
    let (trainnames, traingrayvals) = load_mnist_data(trainpath)?;
    let (testname, testgrayvals) = load_mnist_data(testpath)?;
    let totclasses = 10;
    let trainoh = onehot(&trainnames, totclasses);
    let nodes = 784;
    let hidden = 128;
    let out = 10;
    let epochs = 10;
    let learnspeed = 0.01;
    let size = 64;
    let mut nn = NeuralNetwork::new(nodes, hidden, out);
    train(&mut nn, &traingrayvals, &trainoh, epochs, learnspeed, size);
    evaluate(&nn, &testgrayvals, &testname);
    Ok(())
}